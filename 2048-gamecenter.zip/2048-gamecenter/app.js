
/**
 * Module dependencies.
 */
var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var http = require('http');
var path = require('path');

var mongo = require('mongodb');


var app = express();

var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/local';


// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', function (req, res) {
  res.set('Content-Type', 'text/html');
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (err, col){
      col.find().sort({score:-1}).limit(100).toArray(function(er, cursor){
        if (!err) {
          var indexPage = "<!DOCTYPE HTML><html><head><title>2048 Game Center</title></head><body><h1>2048 Game Center</h1><table><tr><th>User</th><th>Score</th><th>Timestamp</th></tr>";
          
          for (var count = 0; count < cursor.length; count++) {
            indexPage += "<tr><td>" + cursor[count].username + "</td><td>" + cursor[count].score + "</td><td>" + cursor[count].created_at+ "</td><tr>";
          }
          indexPage += "</table></body></html>";
          res.send(indexPage);
        }
      });
    });
  });
});


app.get('/scores.json', function (req, res){
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, col){
      var user = req.query.username;
      if (user) {
        col.find({"username": user}).sort({score:-1}).limit(100).toArray(function(err, x) {
          res.send(x);
        });
      } else {
        var d = col.find({}).toArray(function(err, x){
          console.log(x);
        });
        col.find({}).sort("name").toArray(function(e, x){
          res.send(x);
        });
      }
    });
  });
});

app.post('/submit.json', function (req, res){
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, collection){
      var score = parseInt(req.body.score);
      var name = req.body.username;
      var grid = req.body.grid;
      var currentdate = new Date();
      var month = currentdate
      var date = new Date();
      var created_at = date.getDate().toString() + "/";
      created_at += (date.getMonth() + 1).toString() + "/";
      created_at += date.getFullYear().toString() + " ";
      created_at += date.getHours().toString() + ":";
      created_at += date.getMinutes().toString();

      if (score && name && grid) {
        collection.insert({"score": score, "username": name, "grid": grid, "created_at": created_at}, function (err, r){});
        res.send("success.");      
      } else {
        res.send("failure: data field(s) missing.")
      }
    });
  });
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
